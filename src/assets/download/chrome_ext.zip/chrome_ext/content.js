var readInterval = startInterval();
var userIdentification;

popup();

function startInterval() {
    var int = setInterval("checkJobList()", 500);
    return int;
}

function stopInterval(interval){
    clearInterval(interval);
}

function checkJobList(){
    // Check if multiple jobs
    let jobList = $(".jobs-list");
    if (jobList.length >= 1){
        stopInterval(readInterval);
        processJobs();
    }
    // Check if one job
    let jobTab = $("#tab_log");
    if (jobTab.length >= 1){
        stopInterval(readInterval);
        processJobTab(jobTab[0]);
    }
}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        // listen for messages sent from background.js
        if (request.message === 'tab changed') {
            stopInterval(readInterval);
            readInterval = startInterval();
        }
    });

function openInNewTab(url) {
    var win = window.open(url, '_blank');
    win.focus();
}

function processJobs() {
    let jobList = $(".jobs-list")[0];
    for(let i = 0; i < jobList.children.length; i++){
       processJob(jobList.children.item(i));
    }
}

function processJob(job) {

    let className = job.className;
    // TODO: Only on failed ones?
    if(true){
        let atag = job.children.item(0);
        let href = atag.href.split("/");
        let jobid = href[href.length-1];
        let div = atag.children.item(1);
        div.appendChild(createButton(jobid));
    }
}

function processJobTab(jobTab) {
    let href = jobTab.href.split("/");
    let jobid = href[href.length-1];
    if(jobTab.children.length > 0) {
      while (jobTab.children.length > 1 && jobTab.lastChild) {
        jobTab.removeChild(jobTab.lastChild);
      }
    } else {
      jobTab.appendChild(createButton(jobid));
    }

    console.log(href);
}


function createButton(jobid) {
    var button = document.createElement("button");
    var img = document.createElement("img");
    img.src = chrome.extension.getURL("compare.png");
    img.height = 20;
    img.width = 20;
    img.style.marginLeft = "10px";
    img.onclick = function(e) { e.stopPropagation();openInNewTab("https://web.blogdiff.net/differencing?jobId="+jobid+"&userId="+userIdentification); };
    return img;
}

function getRandomToken() {
    var randomPool = new Uint8Array(32);
    crypto.getRandomValues(randomPool);
    var hex = '';
    for (var i = 0; i < randomPool.length; ++i) {
        hex += randomPool[i].toString(16);
    }
    return hex;
}

chrome.storage.sync.get('userid', function(items) {
    var userid = items.userid;
    if (userid) {
        useToken(userid);
    } else {
        userid = getRandomToken();
        chrome.storage.sync.set({userid: userid}, function() {
            useToken(userid);
        });
    }
    function useToken(userid) {
        userIdentification = userid;
    }
});


function popup(){
  chrome.storage.sync.get('surveyDone', function(items) {
      var done = items.surveyDone;
      if (!done) {
        var btnYes = document.createElement("button");
        btnYes.style.backgroundColor = "#adc2bf";
        btnYes.style.border = "0px";
        btnYes.style.color = "#ffffff";
        btnYes.style.padding = "5px";
        btnYes.innerHTML = "I will help!";
        btnYes.style.marginRight = "5px";
        btnYes.onclick = function(e) {e.stopPropagation();openInNewTab("https://web.blogdiff.net/survey?source=1"); closePopup();surveyDone();};


        var btnNo = document.createElement("button");
        btnNo.style.backgroundColor = "#adc2bf";
        btnNo.style.border = "0px";
        btnNo.style.color = "#ffffff";
        btnNo.style.padding = "5px";
        btnNo.innerHTML = "No, I am not interested.";
        btnNo.onclick = function(e) {e.stopPropagation();closePopup();};

        var p1 = document.createElement("p");
        p1.style.fontWeight = "bold";
        p1.style.display = "inline-block";
        p1.innerHTML = "Please help BLogDiff!"

        var p2 = document.createElement("p");
        p2.innerHTML = "With only 3 minutes of your time, you could help us improve our tool! Data collected in the survey will only be used for scientific purposes!";

        var img = document.createElement("img");
        img.src = chrome.extension.getURL("compare.png");
        img.style.height = "20px"
        img.style.marginRight = "5px";

        var div = document.createElement("div");
        div.id = "surveyDiv";
        div.style.position = "fixed";
        div.style.bottom = "0";
        div.style.right = "0";
        div.style.height = "auto";
        div.style.width = "300px";
        div.style.padding = "20px";
        div.style.border = "1px solid #dfdfdf";
        div.style.fontFamily = "sans-serif";
        div.style.backgroundColor = "white";
        div.style.zIndex = "1000";

        div.appendChild(img);
        div.appendChild(p1);
        div.appendChild(p2);
        div.appendChild(btnYes);
        div.appendChild(btnNo);
        document.body.appendChild(div);
      }
  });

}

function surveyDone(){
  chrome.storage.sync.set({surveyDone: true}, function() {});
}
function closePopup(){
  $("#surveyDiv").remove();
}
